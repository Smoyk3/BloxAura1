BloxAura Overlay — Zero-Dependency Android Project
==================================================
Этот проект написан на чистом Java + Android SDK (без сторонних зависимостей, Kotlin и AndroidX).

Способ 1 (если есть Android SDK и Gradle / GitHub Actions):
  gradle assembleDebug
  -> app/build/outputs/apk/debug/app-debug.apk

Способ 2 (без Gradle, через command-line Android SDK):
  chmod +x build_apk.sh && ./build_apk.sh
  -> build/out/BloxAuraOverlay.apk

Примечание: для сборки бинарного .apk в среде запуска должен быть установлен Android SDK (android.jar, aapt2, d8, apksigner) и JDK.
