package com.bloxaura.overlay;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0B0E14);
        root.setPadding(48, 96, 48, 48);

        TextView title = new TextView(this);
        title.setText("BloxAura Overlay");
        title.setTextSize(22f);
        title.setTextColor(Color.WHITE);
        title.setPadding(0, 0, 0, 16);

        TextView subtitle = new TextView(this);
        subtitle.setText("Пресет: Future Cinema · Фильтр и прицел поверх оригинального Roblox");
        subtitle.setTextSize(14f);
        subtitle.setTextColor(0xFF94A3B8);
        subtitle.setPadding(0, 0, 0, 36);

        Button launchBtn = new Button(this);
        launchBtn.setText("Включить визуалы и открыть Roblox");
        launchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!Settings.canDrawOverlays(MainActivity.this)) {
                    Intent permIntent = new Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName())
                    );
                    startActivity(permIntent);
                    return;
                }

                Intent svcIntent = new Intent(MainActivity.this, VisualOverlayService.class);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(svcIntent);
                } else {
                    startService(svcIntent);
                }

                try {
                    Intent robloxIntent = new Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse("roblox://navigation/home")
                    );
                    startActivity(robloxIntent);
                } catch (Exception ignored) {
                    Toast.makeText(
                            MainActivity.this,
                            "Оверлей включён. Откройте установленный Roblox.",
                            Toast.LENGTH_SHORT
                    ).show();
                }
            }
        });

        Button stopBtn = new Button(this);
        stopBtn.setText("Отключить оверлей");
        stopBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopService(new Intent(MainActivity.this, VisualOverlayService.class));
            }
        });

        root.addView(title);
        root.addView(subtitle);
        root.addView(launchBtn);
        root.addView(stopBtn);
        setContentView(root);
    }
}
