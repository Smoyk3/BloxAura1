#!/usr/bin/env bash
set -euo pipefail

# Автономная сборка APK без Gradle и без интернета (требуется Android SDK + JDK)
ANDROID_JAR="${ANDROID_HOME}/platforms/android-34/android.jar"
BUILD_TOOLS="$(ls -d "${ANDROID_HOME}/build-tools/"* | sort -V | tail -n 1)"

mkdir -p build/obj build/dex build/out

"${BUILD_TOOLS}/aapt2" link \
  -I "${ANDROID_JAR}" \
  --manifest app/src/main/AndroidManifest.xml \
  -o build/base.apk

javac -source 11 -target 11 -classpath "${ANDROID_JAR}" -d build/obj \
  app/src/main/java/com/bloxaura/overlay/MainActivity.java \
  app/src/main/java/com/bloxaura/overlay/VisualOverlayService.java

"${BUILD_TOOLS}/d8" --lib "${ANDROID_JAR}" --output build/dex \
  build/obj/com/bloxaura/overlay/*.class

cp build/base.apk build/unsigned.apk
(cd build/dex && zip -u ../unsigned.apk classes.dex)

"${BUILD_TOOLS}/zipalign" -f 4 build/unsigned.apk build/aligned.apk

if [ ! -f build/debug.keystore ]; then
  keytool -genkey -v -keystore build/debug.keystore -storepass android \
    -alias androiddebugkey -keypass android -keyalg RSA -keysize 2048 \
    -validity 10000 -dname "CN=Android Debug,O=Android,C=US"
fi

"${BUILD_TOOLS}/apksigner" sign --ks build/debug.keystore \
  --ks-pass pass:android --key-pass pass:android \
  --out build/out/BloxAuraOverlay.apk build/aligned.apk

echo "APK готов: build/out/BloxAuraOverlay.apk"
